﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Serial_Communication_sample_wpf_ver
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
