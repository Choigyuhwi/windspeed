﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Numeric_Conversion_wpf_ver
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
